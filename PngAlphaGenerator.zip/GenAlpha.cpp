#include "pngwriter.h"

int main()
{
	pngwriter writer(128, 128, 0, "out.png");

	writer.line(10, 10, 100, 100, 65535, 65535, 65535);

	writer.write_png();
	writer.close();

	return 0;
}
